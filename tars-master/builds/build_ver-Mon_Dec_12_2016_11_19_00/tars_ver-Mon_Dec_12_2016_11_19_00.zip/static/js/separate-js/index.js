$(document).ready(function() {
    
    

$("#footer_smb").click(function() {
    
    $("#footer_smb_inp").trigger('click');
});
    
    



   
    
   
$("#openmenu_button").click(function() {
    openMenu();  
});
    
    
$("#closemenu_button").click(function() {   
    openMenu();
});
    
     
    

    
});